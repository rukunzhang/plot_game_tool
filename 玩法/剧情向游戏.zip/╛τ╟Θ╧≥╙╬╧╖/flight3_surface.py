import cfg
from cfg import *

# 界面跳转逻辑控制
str_back = Write("返回", color=color_white, font=font_path2, size=30)
rect_back = WriteRect(write=str_back, color=(0, 200, 0))
running = True

class Tub(object):
    def __init__(self, pos):
        self.pos = pos
        self.health = 1
        self.color = "blue"
        self.center = self.pos
        self.radius = 5
        self.width = 0

    def move(self, key):
        if self.pos[0] - 10 < 400:
            if self.pos[0] - 10 > 380:
                if int(self.pos[1]/100) - 1 == key:
                    self.health = 0
                    return
        self.pos = (self.pos[0] - 10, self.pos[1])
        self.center = self.pos

    def show(self, screen):
        pygame.draw.circle(screen, self.color, self.center, self.radius, self.width)

    def get_health(self):
        return self.health


def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption(title_name)
    clock = pygame.time.Clock()

    ball = []
    player1 = Player(image_pl1, "少年")
    func = 0
    cout = 0

    global running
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE or event.key == pygame.K_SPACE:
                    pygame.quit()
                    sys.exit()
                if event.key == pygame.K_q:
                    func = 0
                if event.key == pygame.K_w:
                    func = 1
                if event.key == pygame.K_s:
                    func = 2
                if event.key == pygame.K_x:
                    func = 3
        cout += 1
        if cout == 10:
            ball.append(Tub((600, random.randint(220, 480))))
            cout = 0
        screen.fill((170, 170, 170))
        if func:
            pygame.draw.rect(screen, cfg.color_black, [400, 100 + func * 100, 3, 100], 0)
        player1.show_image(pos_pl[cfg.story1_pl_show[0][1]], screen)
        sum = []
        for i in range(len(ball)):
            if ball[i].get_health() == 0:
                sum.append(i)
        try:
            for i in range(len(sum)):
                ball.pop(sum[-1])
        except IndexError:
            pass
        for i in range(len(ball)):
            ball[i].move(func)
            ball[i].show(screen)
        pygame.display.flip()
        clock.tick(60)


if __name__ == '__main__':
    main()
