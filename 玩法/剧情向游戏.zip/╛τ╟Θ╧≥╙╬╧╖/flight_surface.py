import cfg
from cfg import *

# 界面跳转逻辑控制
str_back = Write("返回", color=color_white, font=font_path2, size=30)
rect_back = WriteRect(write=str_back, color=(0, 200, 0))
running = True


# 相关背景素材设置
text_now = ["战斗开始", "长按鼠标左键蓄力"]
background1 = Img(path=cfg.image_kg11)
str_1_1 = Paragraph(text=text_now[0], color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
player1 = Player(image_pl1, "少年")
player2 = Player(image_pl3, "师傅")

def show(screen, story_number):
    # 相关素材绘制
    # screen.fill((170, 170, 170))
    background1.show((400, 300), screen, mode=4)
    rect_back.show((50, 50), screen)
    player1.show_image(pos_pl[1], screen)
    player2.show_image(pos_pl[6], screen)
    str_1_1.slow_show((100, 400), screen, 1)


def func(x, y, key):
    # 相关事件判定
    # pos = (x, y)
    # if rect_back.is_event(pos):
    #     global running
    #     running = False
    # if key in [i for i in range(story_num[0], story_num[1])]:
    #     str_1_1.setting_text(text=cfg.text[key + 1])
    #     print(key)
    #     return key + 1
    # if key in [i for i in range(story_num[2], story_num[3])]:
    #     str_1_1.setting_text(text=cfg.text[key + 1])
    #     print(key)
    #     return key + 1
    # if key in [i for i in range(story_num[4], story_num[5])]:
    #     str_1_1.setting_text(text=cfg.text[key + 1])
    #     print(key)
    #     return key + 1
    # if key in [i for i in range(story_num[6], story_num[7])]:
    #     str_1_1.setting_text(text=cfg.text[key + 1])
    #     print(key)
    #     return key + 1
    # if key in [i for i in range(story_num[8], story_num[9])]:
    #     str_1_1.setting_text(text=cfg.text[key + 1])
    #     print(key)
    #     return key + 1
    # print("change")
    return key + 1

def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption(title_name)
    clock = pygame.time.Clock()

    func_len = 0
    func_add = 0
    func_sub = 0
    setting_len = [170, 180]
    global running
    story_number = 1
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE or event.key == pygame.K_SPACE:
                    pygame.quit()
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                # x, y = event.pos
                # story_number = func(x, y, story_number)
                func_add = 2
                func_sub = 0
            if event.type == pygame.MOUSEBUTTONUP:
                func_add = 0
                func_sub = 10
                print(f"蓄势{func_len/2}%")
        # show(screen, story_number)
        screen.fill((170, 170, 170))
        func_len += func_add - func_sub
        func_len = 0 if func_len < 0 else func_len
        func_len = 200 if func_len > 200 else func_len

        pygame.draw.rect(screen, "yellow", [300 + setting_len[0], 450, setting_len[1] - setting_len[0], 30], 0)
        pygame.draw.rect(screen, cfg.color_white, [300, 450, func_len, 30], 0)
        pygame.draw.rect(screen, cfg.color_black, [300, 450, 200, 30], 2)

        pygame.display.flip()
        clock.tick(60)


if __name__ == '__main__':
    main()
