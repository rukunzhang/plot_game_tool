import cfg
from cfg import *
import mean_surface


running = True


# 相关背景素材设置
background7 = Img(path=cfg.image_kg3)
# background7 = Img(path=cfg.image_kg4)
# background7 = Img(path=cfg.image_kg7)
str_start = Write("游戏开始", color="red", font=cfg.font_path2, size=30)
str_title = Write("蓝桥榜", color="red", font=cfg.font_path2, size=50)
str_mean = Write("游戏说明", color="red", font=cfg.font_path2, size=30)
rect_start = WriteRect(write=str_start, color=color_white)
rect_title = WriteRect(write=str_title, color=None)
rect_mean = WriteRect(write=str_mean, color=color_white)
str_1_1 = Paragraph(text="一处无名小山，深夜院宅中，两道黑影在缠斗，黑风一吹，两道黑影分立两侧，细辨二者喘息声，料想是胜负已分", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_2 = Paragraph("趁着屋内烛火闪烁，依稀分辨左侧是位老者，右侧是位壮年男子", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_3 = Paragraph("二者一身劲装，款式确是别无二致，老者站立如松，壮年男子摇晃不定", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_4 = Paragraph("只听壮年男子大喘气道", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_5 = Paragraph("师傅，家慈罹患绝症，此番举动实为不得而已……", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_6 = Paragraph("一道冷冽而又无奈的声音打断道", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_7 = Paragraph("规矩就是规矩，念你本心不坏，回去尽孝吧，出得此门莫要再叫我师傅", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_8 = Paragraph("师傅，力量……", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_9 = Paragraph("还不快滚（屋内烛火明灭不定）", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_10 = Paragraph("男子咬了咬牙", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_11 = Paragraph("今日不尽我意，倘若家中真有变故，他日休怪我心狠手辣", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_12 = Paragraph("唰的一声，壮年男子化为一道黑影离开", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_13 = Paragraph("出来吧（老者叹息道）", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_14 = Paragraph("屋门打开，一位总角少年探出头来，师傅，师兄他真的走了吗", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_15 = Paragraph("走了，已经走了，以后他便不是你师兄了", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_16 = Paragraph("少年低下了头", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_17 = Paragraph("老者一声叹息，抬头望夜，（其实再过一年，以他之才智，习得这份力量不成问题）", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_18 = Paragraph("来，总角了，今日我便送你一份礼物", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_19 = Paragraph("关上的门挡住了屋外的伤杂", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_20 = Paragraph("……", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_21 = Paragraph("为师一派，世代守护五岳之力", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_22 = Paragraph("五岳之力，掌控生死奥秘，却总是为外人所觊觎", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
str_1_23 = Paragraph("这护符，便是你的第一份五岳之力，好好感悟它，以后要好好守护它", color=color_white, font=cfg.font_path2, size=story_font_size, length=20)




def show(screen, story_number=0):
    # 相关素材绘制
    if story_number == 1:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_1.slow_show((100, 400), screen, 1)
    if story_number == 2:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_2.slow_show((100, 400), screen, 1)
    if story_number == 3:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_3.slow_show((100, 400), screen, 1)
    if story_number == 4:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_4.slow_show((100, 400), screen, 1)
    if story_number == 5:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_5.slow_show((100, 400), screen, 1)
    if story_number == 6:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_6.slow_show((100, 400), screen, 1)
    if story_number == 7:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_7.slow_show((100, 400), screen, 1)
    if story_number == 8:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_8.slow_show((100, 400), screen, 1)
    if story_number == 9:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_9.slow_show((100, 400), screen, 1)
    if story_number == 10:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_10.slow_show((100, 400), screen, 1)
    if story_number == 11:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_11.slow_show((100, 400), screen, 1)
    if story_number == 12:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_12.slow_show((100, 400), screen, 1)
    if story_number == 13:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_13.slow_show((100, 400), screen, 1)
    if story_number == 14:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_14.slow_show((100, 400), screen, 1)
    if story_number == 15:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_15.slow_show((100, 400), screen, 1)
    if story_number == 16:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_16.slow_show((100, 400), screen, 1)
    if story_number == 17:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_17.slow_show((100, 400), screen, 1)
    if story_number == 18:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_18.slow_show((100, 400), screen, 1)
    if story_number == 19:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_19.slow_show((100, 400), screen, 1)
    if story_number == 20:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_20.slow_show((100, 400), screen, 1)
    if story_number == 21:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_21.slow_show((100, 400), screen, 1)
    if story_number == 22:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_22.slow_show((100, 400), screen, 1)
    if story_number == 23:
        screen.fill(color_black)
        background7.show((400, 280), screen, mode=4)
        str_1_23.slow_show((100, 400), screen, 1)

def func(x, y, story_number=0):
    # 相关事件判定
    pos = (x, y)
    static_num = [i for i in range(1, 24)]
    if story_number in static_num:
        return story_number + 1
    return story_number

def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("贺新春")

    clock = pygame.time.Clock()

    global running
    story_number = 1
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE or event.key == pygame.K_SPACE:
                    pygame.quit()
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos
                story_number = func(x, y, story_number)
        show(screen, story_number)
        pygame.display.flip()
        clock.tick(60)


if __name__ == '__main__':
    main()
