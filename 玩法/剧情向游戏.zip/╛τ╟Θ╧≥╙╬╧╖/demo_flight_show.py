import cfg
from cfg import *

# todo:剧情板块
#  传入剧情编号选择播放的剧情
#  剧情播放：绘制背景，绘制人物，绘制台词
#  方式：幻灯片式，单击以进行，全部剧情结束退出

# 界面跳转逻辑控制
str_back = Write("返回", color=color_white, font=font_path2, size=30)
rect_back = WriteRect(write=str_back, color=(0, 200, 0))
str_back1 = Write("单击鼠标以继续……", color=color_white, font=font_path2, size=30)
rect_back1 = WriteRect(write=str_back1, color=(0, 200, 0))
running = True
key_story = 0
demo_start = 0

# 游戏规则加载
text = """
《《1.按住q键进行格挡，格挡期间受到伤害降低五倍，但是不能攻击》》、、、、、、、、、、、、、、、、、、、、、、、、、
《《2.按住a键进行蓄力，松开a键发起攻击》》、、、、、、
《《3.当蓄力到黄色区间时，会立即进入连击状态，在此期间对敌人造成真伤，且攻击力乘十倍，敌人停止攻击》》、、、、、、、
《《4.点击空格进行暂停和取消暂停，但是还没做好》》
"""
# 相关背景素材设置
background1 = Img(path=cfg.image_kg1)
str_1_1 = Paragraph(text=text, color=color_white, font=cfg.font_path2, size=story_font_size, length=40)


def show(screen):
    # 相关素材绘制
    screen.fill((170, 170, 170))
    str_1_1.show((100, 150), screen, length=30)
    rect_back.show((50, 50), screen)
    return


def func(x, y):
    # 相关事件判定
    global running
    pos = (x, y)
    if rect_back.is_event(pos):
        running = False


def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("贺新春")
    clock = pygame.time.Clock()

    global running
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos
                func(x, y)
        show(screen)
        pygame.display.flip()
        clock.tick(60)
    return


if __name__ == '__main__':
    main()
