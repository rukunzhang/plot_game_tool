import cfg
from cfg import *

# 界面跳转逻辑控制
str_back = Write("返回", color=color_white, font=font_path2, size=30)
rect_back = WriteRect(write=str_back, color=(0, 200, 0))
running = True


def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption(title_name)
    clock = pygame.time.Clock()
    player1 = Player(image_pl1, "少年")
    func_len = 0
    func_add = 0
    func_sub = 0
    setting_len = [170, 180]
    global running
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE or event.key == pygame.K_SPACE:
                    pygame.quit()
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                func_add = 2
                func_sub = 0
            if event.type == pygame.MOUSEBUTTONUP:
                func_add = 0
                func_sub = 10
                print(f"蓄势{func_len/2}%")
        screen.fill((170, 170, 170))
        func_len += func_add - func_sub
        func_len = 0 if func_len < 0 else func_len
        func_len = 200 if func_len > 200 else func_len

        pygame.draw.rect(screen, "yellow", [300 + setting_len[0], 450, setting_len[1] - setting_len[0], 30], 0)
        pygame.draw.rect(screen, cfg.color_white, [300, 450, func_len, 30], 0)
        pygame.draw.rect(screen, cfg.color_black, [300, 450, 200, 30], 2)
        player1.show_image(pos_pl[cfg.story1_pl_show[0][1]], screen, mode=0)
        pygame.display.flip()
        clock.tick(60)


if __name__ == '__main__':
    main()
