
import cfg
from cfg import *

str_back = Write("返回", color=color_black, font=font_path2, size=30)
rect_back = WriteRect(write=str_back, color=(0, 200, 0))
running = True

def show(screen):
    # 相关素材绘制
    screen.fill((180, 180, 180))
    rect_back.show((50, 50), screen)


def func(x, y):
    # 相关事件判定
    pos = (x, y)
    if rect_back.is_event(pos):
        global running
        running = False


def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("贺新春")

    clock = pygame.time.Clock()
    global running
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos
                func(x, y)
        show(screen)
        pygame.display.flip()
        clock.tick(60)

if __name__ == '__main__':
    main()