import cfg
from cfg import *

# 相关背景素材设置
str1 = Write("《健康游戏忠告》", color=color_white, font=cfg.font_path3, size=15)
str2 = Write("抵制不良游戏，拒绝盗版游戏。", color=color_white, font=cfg.font_path3, size=15)
str3 = Write("注意自我保护，谨防受骗上当。", color=color_white, font=cfg.font_path3, size=15)
str4 = Write("适度游戏益脑，沉迷游戏伤身。", color=color_white, font=cfg.font_path3, size=15)
str5 = Write("合理安排时间，享受健康生活。", color=color_white, font=cfg.font_path3, size=15)
rect1 = WriteRect(write=str1, color=None)
rect2 = WriteRect(write=str2, color=None)
rect3 = WriteRect(write=str3, color=None)
rect4 = WriteRect(write=str4, color=None)
rect5 = WriteRect(write=str5, color=None)
str_back = Write("返回", color=color_black, font=font_path2, size=30)
rect_back = WriteRect(write=str_back, color=(0, 200, 0))
str11 = Write("游戏策划：韩宇轩", color=color_white, font=cfg.font_path3, size=20)
str12 = Write("编程负责：张汝坤", color=color_white, font=cfg.font_path3, size=20)
str13 = Write("素材来源：b站乃贝上大分", color=color_white, font=cfg.font_path3, size=20)
str14 = Write("游戏结局：Bad,Good,Perfect", color=(200, 100, 100), font=cfg.font_path3, size=20)
rect11 = WriteRect(write=str11, color=None)
rect12 = WriteRect(write=str12, color=None)
rect13 = WriteRect(write=str13, color=None)
rect14 = WriteRect(write=str14, color=None)
running = True


def show(screen):
    # 相关素材绘制
    screen.fill((180, 180, 180))
    height = 450
    rect1.show((400, height), screen, write_mode=4)
    rect2.show((400, height + 20), screen, write_mode=4)
    rect3.show((400, height + 40), screen, write_mode=4)
    rect4.show((400, height + 60), screen, write_mode=4)
    rect5.show((400, height + 80), screen, write_mode=4)
    rect_back.show((50, 50), screen)
    height = 200
    rect11.show((400, height), screen, write_mode=4)
    rect12.show((400, height + 30), screen, write_mode=4)
    rect13.show((400, height + 60), screen, write_mode=4)
    rect14.show((400, height + 150), screen, write_mode=4)


def func(x, y):
    # 相关事件判定
    pos = (x, y)
    if rect_back.is_event(pos):
        global running
        running = False


def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("贺新春")

    clock = pygame.time.Clock()
    global running
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos
                func(x, y)
        show(screen)
        pygame.display.flip()
        clock.tick(60)


if __name__ == '__main__':
    main()
