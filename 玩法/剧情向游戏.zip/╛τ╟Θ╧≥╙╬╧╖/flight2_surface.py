import cfg
from cfg import *

# 界面跳转逻辑控制
str_back = Write("返回", color=color_white, font=font_path2, size=30)
rect_back = WriteRect(write=str_back, color=(0, 200, 0))
running = True



def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption(title_name)
    clock = pygame.time.Clock()

    func_num = 0
    func_time = 0
    func_write = Write(f"当前连击数：{func_num}", color=color_black, font=font_path2, size=30)
    player1 = Player(image_pl1, "少年")

    global running
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE or event.key == pygame.K_SPACE:
                    pygame.quit()
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                func_num += 1
                func_time = 15
        screen.fill((170, 170, 170))
        func_time -= 1
        if func_time < 1:
            func_num = 0
        if func_num > 0:
            func_write.setting(f"当前连击数：{func_num}")
            func_write.show((600, 200), screen)
            pygame.draw.rect(screen, cfg.color_white, [600, 230, func_time * 10, 10], 0)
            pygame.draw.rect(screen, cfg.color_black, [600, 230, 150, 10], 2)
        player1.show_image(pos_pl[cfg.story1_pl_show[0][1]], screen)
        pygame.display.flip()
        clock.tick(60)


if __name__ == '__main__':
    main()
