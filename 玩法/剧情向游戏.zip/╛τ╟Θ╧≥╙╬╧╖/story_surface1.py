import cfg
from cfg import *

# 界面跳转逻辑控制
str_back = Write("返回", color=color_white, font=font_path2, size=30)
rect_back = WriteRect(write=str_back, color=(0, 200, 0))
running = True


# 相关背景素材设置
background1 = Img(path=cfg.image_kg3)
str_1_1 = Paragraph(text=cfg.text[1], color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
player1 = Player(image_pl1, "少年")
player2 = Player(image_pl3, "师傅")
player3 = Player(image_pl4, "师兄")

def show(screen, story_number):
    # 相关素材绘制
    screen.fill(color_black)
    background1.show((400, 280), screen, mode=4)
    rect_back.show((50, 50), screen)
    player1.show_image(pos_pl[cfg.story1_pl_show[0][story_number]], screen)
    player2.show_image(pos_pl[cfg.story1_pl_show[1][story_number]], screen)
    player3.show_image(pos_pl[cfg.story1_pl_show[2][story_number]], screen)
    str_1_1.slow_show((100, 400), screen, 1)


def func(x, y, key):
    # 相关事件判定
    pos = (x, y)
    if rect_back.is_event(pos):
        global running
        running = False
    if key in [i for i in range(story_num[0], story_num[1])]:
        str_1_1.setting_text(text=cfg.text[key + 1])
        print(key)
        return key + 1
    if key in [i for i in range(story_num[2], story_num[3])]:
        str_1_1.setting_text(text=cfg.text[key + 1])
        print(key)
        return key + 1
    if key in [i for i in range(story_num[4], story_num[5])]:
        str_1_1.setting_text(text=cfg.text[key + 1])
        print(key)
        return key + 1
    if key in [i for i in range(story_num[6], story_num[7])]:
        str_1_1.setting_text(text=cfg.text[key + 1])
        print(key)
        return key + 1
    if key in [i for i in range(story_num[8], story_num[9])]:
        str_1_1.setting_text(text=cfg.text[key + 1])
        print(key)
        return key + 1
    print("change")
    return key + 1

def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("贺新春")

    clock = pygame.time.Clock()

    global running
    story_number = 1
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE or event.key == pygame.K_SPACE:
                    pygame.quit()
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos
                story_number = func(x, y, story_number)
        show(screen, story_number)
        pygame.display.flip()
        clock.tick(60)


if __name__ == '__main__':
    main()
