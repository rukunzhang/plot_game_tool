import cfg
from cfg import *
import demo_flight_show

# todo:战斗板块
#  直接进入战斗，绘制战斗背景
#  绘制人物状态：人物图像，人物名称，人物血条
#  绘制双方战斗状态
# todo:战斗
#  主角正常有防御和蓄力两种状态，
#  防御状态可以自由取消与设定，
#  蓄力状态常设，不限蓄力时长，蓄力结束蓄力条清空，若不处于防御状态可发动攻击，若处于防御状态无事发生
#  当蓄力恰到好处并发动一次攻击时，对手陷入昏厥，此时进入连击状态
#  敌人自由进行防御与攻击
#  防御时，受到攻击伤害降低一半
#  蓄力条距离perfect处越近，伤害越高
#  连击状态随连击数延长，延长时间待定

# todo:角色内部属性
#  角色有攻击倍率，防御倍率，生命倍率
#  角色血条固定，根据倍率内部计算具体生命值
#  角色防御倍率隐藏，在受到伤害时内部影响具体生命值
#  角色攻击倍率，内部属性，对于攻击的攻击具体值产生影响


# 界面跳转逻辑控制
str_back = Write("返回", color=color_white, font=font_path2, size=30)
rect_back = WriteRect(write=str_back, color=(0, 200, 0))
str_back1 = Write("规则", color=color_white, font=font_path2, size=30)
rect_back1 = WriteRect(write=str_back1, color=(0, 200, 0))
running = True
stop = False
vector = 0
# 相关背景素材设置
background1 = Img(path=cfg.image_kg1)
str_1_1 = Paragraph(text=text[1], color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
player1 = Player(image_pl2, "少年")
# player2 = Player(image_pl5, "卫兵")
player2 = Player(image_pl6, "法贾")
player1.setting_shield()
# 攻击模块
ak_add_mode = 2
ak_len = 0
ak_add = 0
ak_set_len = [150, 180]
ak_bu = []
ak_bu1 = []
ak_count = 0
ak_count_max = 100
ak_count_add = 1
ak_buff_time = 0
ak_buff = 0
ak_num = 0
ak_write = Write(f"当前连击数：{ak_num}", color=color_black, font=font_path2, size=30)

# 护盾模块
shield_mode = False
def show(screen):
    # 相关素材绘制

    # 绘制背景
    screen.fill((170, 170, 170))
    # background1.show((400, 300), screen, mode=4)

    # 绘制人物
    player1.show((100, 200), screen)
    player2.show((500, 200), screen)

    # 绘制选项
    rect_back1.show((650, 50), screen)
    rect_back.show((50, 50), screen)

    # 绘制蓄力条
    pygame.draw.rect(screen, "yellow", [300 + ak_set_len[0], 450, ak_set_len[1] - ak_set_len[0], 30], 0)
    pygame.draw.rect(screen, cfg.color_white, [300, 450, ak_len, 30], 0)
    pygame.draw.rect(screen, cfg.color_black, [300, 450, 200, 30], 2)

    # 绘制攻击
    for bu_num in range(len(ak_bu)):
        ak_bu[bu_num].show(screen)
    for bu_num in range(len(ak_bu1)):
        ak_bu1[bu_num].show(screen)

    # 绘制护盾
    if player1.is_shield():
        pygame.draw.rect(screen, cfg.color_black, [300, 220, 3, 200], 0)

    # 绘制连击条
    if ak_buff:
        pygame.draw.rect(screen, cfg.color_white, [600, 230, ak_buff_time * 10, 10], 0)
        pygame.draw.rect(screen, cfg.color_black, [600, 230, 200, 10], 2)
        ak_write.setting(f"当前连击数：{ak_num}")
        ak_write.show((600, 250), screen)



def func(x, y):
    # 相关事件判定
    global running
    pos = (x, y)
    if rect_back.is_event(pos):
        running = False
    if rect_back1.is_event(pos):
        demo_flight_show.main()



def main(key):
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("贺新春")
    clock = pygame.time.Clock()
    player1.buff(shield_kis=key)
    # 调取全局参数
    global shield_mode
    global ak_bu
    global ak_len
    global ak_add
    global ak_set_len
    global running
    global stop
    global ak_count
    global ak_count_max
    global ak_count_add
    global vector
    global ak_buff
    global ak_buff_time
    global ak_num
    # global player1
    # global player2
    # player1 = Player(image_pl2, "少年")
    # player2 = Player(image_pl6, "法贾")
    running = True




    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                if event.key == pygame.K_SPACE:
                    stop = not stop
                # 切换防御状态
                if event.key == pygame.K_q:
                    player1.setting_shield()
                # 长按a键蓄力攻击
                if event.key == pygame.K_a:
                    ak_add = ak_add_mode
            if event.type == pygame.KEYUP:
                # 切换防御状态
                if event.key == pygame.K_q:
                    player1.setting_shield()
                # 松开a键发动攻击
                if event.key == pygame.K_a:
                    ak_add = 0
                    if not player1.is_shield():
                        # 攻击时处于buff状态
                        if ak_buff:
                            ak_buff_time = 20
                            ak_num += 1
                            ak_bu.append(Attack(cfg.image_ak1, (120, 400), 10, ak_len * 10))
                        else:
                            ak_bu.append(Attack(cfg.image_ak1, (120, 400), 10, ak_len))
                        # 达成击破效果
                        if ak_len > ak_set_len[0]:
                            if ak_len < ak_set_len[1]:
                                player2.buff(shield_kis=0.01)
                                ak_buff = 1
                                ak_buff_time = 20
                    print(f"蓄势{ak_len / 2}%")
                    ak_len = 0
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos
                func(x, y)


        # 蓄力模块(只能增加不能减少，上限100)
        ak_len += ak_add
        ak_len = 200 if ak_len > 200 else ak_len

        # 判断己方攻击效果
        for bu_num in range(len(ak_bu)):
            # print(type(ak_bu[0]))
            ak_bu[0].move_now()
            if ak_bu[0].get_pos()[0] > 420:
                player2.get_attack(ak_bu.pop(0))
            else:
                ak_bu.append(ak_bu.pop(0))
        # 判定连击状态
        if ak_buff:
            ak_buff_time -= 1
            ak_count_add = 0
            if ak_buff_time == 0:
                ak_buff = 0
                ak_num = 0
                ak_count_add = 1
                player2.buff(shield_kis=1.5)

        # 设定对方攻击
        ak_count += ak_count_add
        if ak_count >= ak_count_max:
            ak_bu1.append(Attack(cfg.image_ak01, (380, 400), -10, 100))
            ak_count = 0
        for bu_num in range(len(ak_bu1)):
            ak_bu1[0].move_now()
            if ak_bu1[0].get_pos()[0] < 220:
                player1.get_attack(ak_bu1.pop(0))
            else:
                ak_bu1.append(ak_bu1.pop(0))
        show(screen)
        pygame.display.flip()

        # 判断游戏是否结束
        if player1.is_die():
            running = False
        if player2.is_die():
            running = False
            vector = 1
        clock.tick(60)

    # 战斗退出时用于判断胜利状态
    if vector == 1:
        return 1
    else:
        return 0


if __name__ == '__main__':
    main()
