import pygame
import sys
import os
import time
import random

# text
file = open("resource/font/文案.txt", mode="r", encoding="utf-8")
text = []
for line in file.readlines():
    text.append(line[:-1])
# 决定文案的展示
story_num = [1, 19, 21, 31, 33, 49, 51, 60, 62, 64]
story1_pl_show = [[i%3 for i in range(100)],
                  [(i+1)%3 for i in range(100)],
                  [(i+2)%3 for i in range(100)]]

# font
# 1为花体字
# 2为粗体字
# 3为宋体字
font_path1 = "resource/font/FZSTK.TTF"
font_path2 = "resource/font/STHUPO.TTF"
font_path3 = "resource/font/STZHONGS.TTF"
story_font_size = 20
# color
color_white = (255, 255, 255)
color_black = (0, 0, 0)

# image
# 依次为开始界面
image_kg1 = "resource/picture/背景（结局一）.png"
image_kg2 = "resource/picture/背景（决战）.png"
image_kg3 = "resource/picture/背景（出山）.png"
image_kg4 = "resource/picture/背景（大雪）.png"
image_kg5 = "resource/picture/背景（对战）.png"
image_kg6 = "resource/picture/背景（灭门）.png"
image_kg7 = "resource/picture/背景（窃取）.png"
image_kg8 = "resource/picture/背景（结局一）.png"
image_kg9 = "resource/picture/背景（结局二）.png"
image_kg10 = "resource/picture/背景（结局三）.png"
image_kg11 = "resource/picture/背景2.jpg"

# 依次为少年、少年出山、师傅、师兄、反派1、反派2、3、4
image_pl1 = "resource/picture/人物（少年1）.png"
image_pl2 = "resource/picture/人物（少年出山1）.png"
image_pl3 = "resource/picture/人物（师傅1）.png"
image_pl4 = "resource/picture/人物（师兄1）.png"
image_pl5 = "resource/picture/人物（反派2）(已去底).png"
image_pl6 = "resource/picture/人物（反派3）(已去底).png"
image_pl7 = "resource/picture/人物（反派4）(已去底).png"
image_pl8 = "resource/picture/人物（反派5）(已去底).png"
# 道具，依次为玉佩暗、玉佩亮、线索
image_th1 = "resource/picture/道具（暗1）.png"
image_th2 = "resource/picture/道具（亮1）.png"
image_th3 = "resource/picture/道具（线索1）.png"
# 攻击特效
image_ak1 = "resource/picture/攻击1.png"
image_ak2 = "resource/picture/攻击2.png"
image_ak3 = "resource/picture/攻击3.png"
image_ak01 = "resource/picture/攻击01.png"

# music
# 暂无


# setting
# 各种参数
pos_pl = [(1000, 1000)]
for i in range(10,60):
    pos_pl.append((i*10, 200))
# pos_pl = [(1000, 1000), (100, 200), (200, 200), (300, 200), (400, 200), (500, 200), (600, 200)]
title_name = "贺新岁"
# class

class Img(object):

    def __init__(self, path=""):
        self.img = img = pygame.image.load(path)
        self.rect = img.get_rect()

    def show(self, pos, screen, mode=0):
        if mode == 0:
            self.rect.topleft = pos
        elif mode == 1:
            self.rect.midtop = pos
        elif mode == 2:
            self.rect.topright = pos
        elif mode == 3:
            self.rect.midleft = pos
        elif mode == 4:
            self.rect.center = pos
        elif mode == 5:
            self.rect.midright = pos
        elif mode == 6:
            self.rect.bottomleft = pos
        elif mode == 7:
            self.rect.midbottom = pos
        elif mode == 8:
            self.rect.bottomright = pos
        screen.blit(self.img, self.rect)

    def setting(self, path):
        self.img = img = pygame.image.load(path)
        self.rect = img.get_rect()



class Write(object):
    # todo：简化文本内容的显示问题
    # 实现功能：传入实现文本内容的过程的所有信息，集成完成
    # 实现过程：
    # 创建font类，获取显示大小，获取字体路径
    # 文字渲染 获取文字，获取颜色
    # 显示,获取坐标，获取显示界面
    # 功能抽象：
    # 属性：font类（默认初始化（不会继承）），文本，颜色（默认初始化）[,其他关于文本的参数]，#坐标，显示界面（非属性）
    # 方法：调整文字，显示文字
    font_all = font_path3
    size_all = 20
    color_all = "black"

    def __init__(self, text="", color=color_all, font=font_all, size=size_all):
        # 传入 文本、文本颜色[、文体路径、文体大小]
        # 默认构建font对象
        self.size = size
        self.font = font
        self.text = text
        self.color = color

    def show(self, pos, screen, mode=0):
        # 传入显示位置、显示界面、显示模式
        font = pygame.font.Font(self.font, self.size)
        text = font.render(self.text, True, self.color)
        text_rect = text.get_rect()
        # 根据mode来决定显示效果，从0到8
        # 左上、中上、右上、左中、正中、右中、左下、中下、右下
        if mode == 0:
            text_rect.topleft = pos
        elif mode == 1:
            text_rect.midtop = pos
        elif mode == 2:
            text_rect.topright = pos
        elif mode == 3:
            text_rect.midleft = pos
        elif mode == 4:
            text_rect.center = pos
        elif mode == 5:
            text_rect.midright = pos
        elif mode == 6:
            text_rect.bottomleft = pos
        elif mode == 7:
            text_rect.midbottom = pos
        elif mode == 8:
            text_rect.bottomright = pos
        screen.blit(text, text_rect)

    @classmethod
    def setting_all(cls, color, font_, size):
        # 更改共有属性
        Write.font_all = font_
        Write.size_all = size
        Write.color_all = color

    def setting_text(self, text=""):
        self.text = text


    @staticmethod
    def show_all():
        # 展示共有属性
        print(Write.font_all)
        print(Write.size_all)
        print(Write.color_all)

    def setting(self, text="", color=color_all, font=font_all, size=size_all):
        # 修改实例的属性
        self.size = size
        self.font = font
        self.text = text
        self.color = color

    @property
    def get_text(self):
        return self.text

    @property
    def get_font(self):
        return self.font

    @property
    def get_color(self):
        return self.color

    @property
    def get_size(self):
        return self.size


class Paragraph(object):
    # todo:解决段落显示问题
    # 实现功能：传入一段文字，设定一行有多少个字符（转换为全角占空），将其以自然段的形式打印到界面上
    # 实现过程：
    # 获取文本信息、文本宽度、字体颜色、字体格式、字体大小
    # 处理文本信息成合适文本宽度的数据、构建Write对象数组
    # 显示内容
    # 功能抽象：
    # 属性：输入文本内容，颜色、字体、大小(默认以Write为准)
    # 方法：调整内部文字信息，调整段落信息，打印

    font_all = "C:/Windows/Fonts/STXINWEI.TTF"
    size_all = 20
    color_all = "black"
    length_all = 20

    def __init__(self, text="", color=color_all, font=font_all, size=size_all, length=length_all):
        # 传入基本文字信息、设定文字的格式
        self.size = size
        self.font = font
        self.text = text
        self.color = color
        self.adjust_text = []
        self.length = length
        self.text_all = text
        self.show_num = 0

    def adjust(self, length=length_all):
        # 根据显示的段落长度需求，创建合适的列表实例
        # 此处将待显示的内容提前处理成Write类
        # todo:考虑首行缩进问题
        adjust_text = []
        text_length = len(self.text)
        if text_length > length:    # 文本内容超过一行
            for i in range(int(text_length / length)+1):
                if i * length < text_length:
                    adjust_text.append(self.text[i * length: (i + 1) * length])
                else:
                    adjust_text.append(self.text[i * length: -1])
        else:
            adjust_text.append(self.text)
        self.adjust_text = [Write(i, self.color, self.font, self.size) for i in adjust_text]

    def show(self, pos, screen, mode=0, length=0):
        # 传入显示位置、显示界面、显示模式
        # 直接设定每一个小块的显示效果即可
        if length != 0:
            self.adjust(length)
        for i in range(len(self.adjust_text)):
            self.adjust_text[i].show((pos[0], pos[1] + i * self.size), screen, mode)

    def slow_show(self,  pos, screen, show_num, mode=0, length=0):
        if self.show_num + show_num <= len(self.text_all):
            self.show_num += show_num
        self.text = self.text_all[:self.show_num]
        self.adjust()
        self.show(pos, screen, mode=mode, length=length)
        time.sleep(0.03)

    def setting(self, text="", color=color_all, font=font_all, size=size_all, length=length_all):
        # 修改实例的属性
        self.size = size
        self.font = font
        self.text = text
        self.color = color
        self.adjust_text = []
        self.length = length
        self.text_all = text
        self.show_num = 0

    def setting_text(self,  text=""):
        self.text = text
        self.adjust_text = []
        self.text_all = text
        self.show_num = 0
    @property
    def get_text(self):
        return self.text

    @property
    def get_font(self):
        return self.font

    @property
    def get_color(self):
        return self.color

    @property
    def get_size(self):
        return self.size

    @property
    def get_length(self):
        return self.length

    @property
    def get_line_num(self):
        return len(self.adjust_text)

class WriteRect(object):
    # 实现功能：为文字添加文本框和各类特效，并判定事件是否触发文本框内效果
    # 实现过程，首先获取文字类的大小信息、位置信息、绘制一个稍大的方框，
    # 此方框应始终伴随文字类并保持相对位置和特效不变
    # 当检测到鼠标信息时，判定鼠标是否落到方框内并返回布尔值
    # 实现方法：直接传入一个实例，内部针对性调用它
    # 实现过程：初始化特效模式，特效颜色，需要特效的类
    # 包含方法：更新各项数据，显示，判断事件
    # 属性：write类，paragraph类，边框大小（根据width调整），边框颜色

    rect_color = (0, 100, 200)
    rect_width = 2
    rect_write = Write()

    def __init__(self, write=rect_write, color=rect_color, width=rect_width):
        self.color = color
        self.width = width
        self.rect = []
        self.write = write

    def show(self, pos, screen, rect_mode=0, write_mode=0, write_length=0):
        # 莫名bug，特判
        if self.write.get_font == font_path3:
            self.write.show(pos, screen, write_mode)
            size = self.write.get_size
            length = len(self.write.get_text)
            self.rect = [pos[0] - self.width, pos[1] - self.width, size * length + self.width * 2,size + self.width * 2]
        else:
            # 显示坐标，显示界面，文本框类与文字类的参数
            self.write.show(pos, screen, write_mode)
            size = self.write.get_size
            length = len(self.write.get_text)
            self.rect = [pos[0] - self.width, pos[1] - self.width, size * length + self.width * 2, size + self.width * 2]
        if self.color is None:
            pass
        else:
            pygame.draw.rect(screen, self.color, self.rect, self.width)

    def is_event(self, pos):
        try:
            if self.rect[0]:
                pass
            key = 0
            if pos[0] > self.rect[0]:
                key += 1
            if pos[0] < self.rect[0] + self.rect[2]:
                key += 1
            if pos[1] > self.rect[1]:
                key += 1
            if pos[1] < self.rect[1] + self.rect[3]:
                key += 1
            if key == 4:
                return True
            return False
        except:
            return False
        finally:
            pass

    def setting(self, write=rect_write, color=rect_color, width=rect_width):
        self.color = color
        self.width = width
        self.rect = []
        self.write = write


class Player(object):
    # 人物类，有人物贴图，人物显示位置，（人物属性，人物动作？）
    def __init__(self, path=None, name=""):
        self.path = path
        self.name = Write(name, color="white")
        self.img = Img(self.path)
        self.health = 100
        self.health_kis = 10
        self.attack_kis = 1
        self.shield = 20
        self.shield_kis = 1.5
        self.mode_shield = True

    def show_image(self, pos, screen, mode=6):
        self.img.show(pos, screen, mode)

    def show_name(self, pos, screen, mode=6):
        self.name.show((pos[0] + 20, pos[1]), screen, mode)

    def show_health(self, pos, screen, mode=6):
        pygame.draw.rect(screen, (200, 200, 200), [pos[0] + 20, pos[1] - 20, 100, 15], 0)
        pygame.draw.rect(screen, color_white, [pos[0] + 20, pos[1] - 20, self.health, 15], 0)
        pygame.draw.rect(screen, color_black, [pos[0] + 20, pos[1] - 20, 100, 15], 2)
        Write(f"{self.health}").show((pos[0] + 50, pos[1] - 50), screen)

    def show(self, pos, screen, mode=0):
        self.show_image(pos, screen, mode)
        self.show_name(pos, screen, mode)
        self.show_health(pos, screen, mode)

    def is_die(self):
        if self.health <= 0:
            return True
        return False

    def is_shield(self):
        return self.mode_shield

    def setting_shield(self):
        self.mode_shield = not self.mode_shield

    def flight(self, attack):
        self.health -= attack - self.shield * self.shield_kis

    # def buff(self, health=0, health_kis=0, attack_kis=0, shield=0, shield_kis=0):
    #     self.health += health
    #     self.health = self.health if self.health <= 100 else 100
    #     self.health_kis = health_kis
    #     self.attack_kis = attack_kis
    #     self.shield = shield
    #     self.shield_kis = shield_kis
    def buff(self, shield_kis=0):
        self.shield_kis = shield_kis

    def get_attack(self, bu):
        health = (bu.health - self.shield * self.shield_kis)
        if health > 0:
            if self.mode_shield:
                self.health -= health / (self.health_kis * 5)
            else:
                self.health -= health / (self.health_kis * 1)


class Attack(object):
    def __init__(self, path=None, pos=(0,0), move=0, health=0):
        self.path = path
        self.img = Img(self.path)
        self.pos = pos
        self.move = move
        self.health = health

    def show(self, screen, mode=6):
        self.img.show(self.pos, screen, mode)

    def move_now(self):
        self.pos = (self.pos[0] + self.move, self.pos[1])

    def get_pos(self):
        return self.pos

    def get_health(self):
        return self.health
