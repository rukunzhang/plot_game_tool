import cfg
from cfg import *

# todo:剧情板块
#  传入剧情编号选择播放的剧情
#  剧情播放：绘制背景，绘制人物，绘制台词
#  方式：幻灯片式，单击以进行，全部剧情结束退出

# 界面跳转逻辑控制
str_back = Write("跳过", color=color_white, font=font_path2, size=30)
rect_back = WriteRect(write=str_back, color=(0, 200, 0))
str_back1 = Write("单击鼠标以继续……", color=color_white, font=font_path2, size=30)
rect_back1 = WriteRect(write=str_back1, color=(0, 200, 0))
running = True
key_story = 0
demo_start = 0

# 游戏剧情加载
text = ["闯荡江湖数周，你已确定第一个仇人的位置，现在你来到了一处哨所，而你的目标“法贾”是这里的军需官",
        "来到了哨所前，你看着哨所的大门，心生犹豫，自己的第一次行动应该怎样开始"]
text1 = ["机敏的你观察到值班的守卫哈欠连连，于是打算找个机会溜进了大门",
         "啊~今天晚上要好好休息，怎么这么困",
         "你灵机一动，趁着守卫仰头闭眼的时候溜进了大门"]
text2 = ["想到把八年前的往事，满脸冷峻的你直接冲了进去",
         "什么人！哨所重地，速速止步",
         "你确实不加理会，直接拔起了刀"]
text3 = ["你站在大门处犹豫不定，这时听到了一声惊喝",
         "鬼鬼祟祟，站在大门前这是要做什么，赶紧滚开，否则视为间谍处置",
         "你心中大惊，想来已是不能再犹豫，否则这仇还报不报了，你咬了咬牙，冲了过去"]
text4 = ["击败守卫后，你看向了守卫手中的刀",
         "你捡了起来，不错的刀，你心里想"]
text5 = ["进入大门，你只一眼便看到了“法贾”",
         "你是何人？",
         "你默默无言，抽出了手中的刀"]
text6 = ["你离开了军营，下一个是谁"]

text7 = ["只是那一刀，你死了……"]

# 人物位置
pos_pl = [[],
          [[1, 23], [0, 0], [0, 0]],
          [[1, 0, 35], [30, 30, 1], [0, 0, 0]],
          [[2, 13, 20], [30, 30, 30], [0, 0, 0]],
          [[2, 2, 23], [30, 23, 40], [0, 0, 0]],
          [[20, 40], [25, 8], [0, 0]],
          [[1, 1, 15], [0, 0, 0], [40, 40, 25]],
          [[38], [0], [0]],
          [[0], [0], [0]],
          [[0], [0], [0]]]

# 相关背景素材设置
background1 = Img(path=cfg.image_kg1)
str_1_1 = Paragraph(text=text[1], color=color_white, font=cfg.font_path2, size=story_font_size, length=20)
player1 = Player(image_pl2, "少年")
player2 = Player(image_pl5, "反派1")
player3 = Player(image_pl6, "反派2")

def show(screen, story_number):
    # 相关素材绘制
    screen.fill(color_black)
    if demo_start == 0:
        rect_back1.show((200, 500), screen)
    if demo_start == 1:
        background1.show((400, 280), screen, mode=4)
        player1.show_image(cfg.pos_pl[pos_pl[key_story][0][story_number - 1]], screen, mode=0)
        player2.show_image(cfg.pos_pl[pos_pl[key_story][1][story_number - 1]], screen, mode=0)
        player3.show_image(cfg.pos_pl[pos_pl[key_story][2][story_number - 1]], screen, mode=0)
        str_1_1.slow_show((100, 400), screen, 1)
        # print(story_number)
    rect_back.show((50, 50), screen)
    return


def func(x, y, story_number):
    # 相关事件判定
    global demo_start
    global running
    pos = (x, y)
    if rect_back.is_event(pos):
        running = False

    if story_number < len(pos_pl[key_story][0]):
        if key_story == 1:
            background1.setting(path=cfg.image_kg5)
            str_1_1.setting_text(text=text[story_number])
            demo_start = 1
        if key_story == 2:
            background1.setting(path=cfg.image_kg5)
            str_1_1.setting_text(text=text1[story_number])
            demo_start = 1
        if key_story == 3:
            background1.setting(path=cfg.image_kg5)
            str_1_1.setting_text(text=text2[story_number])
            demo_start = 1
        if key_story == 4:
            background1.setting(path=cfg.image_kg5)
            str_1_1.setting_text(text=text3[story_number])
            demo_start = 1
        if key_story == 5:
            background1.setting(path=cfg.image_kg5)
            str_1_1.setting_text(text=text4[story_number])
            demo_start = 1
        if key_story == 6:
            background1.setting(path=cfg.image_kg10)
            str_1_1.setting_text(text=text5[story_number])
            demo_start = 1
        if key_story == 7:
            background1.setting(path=cfg.image_kg10)
            str_1_1.setting_text(text=text6[story_number])
            demo_start = 1
        if key_story == 8:
            background1.setting(path=cfg.image_kg5)
            str_1_1.setting_text(text=text7[story_number])
            demo_start = 1
        if key_story == 9:
            background1.setting(path=cfg.image_kg5)
            str_1_1.setting_text(text=text7[story_number])
            demo_start = 1
    elif story_number == len(pos_pl[key_story][0]):
        running = False
        return story_number
    return story_number + 1

def main(key):
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("贺新春")
    clock = pygame.time.Clock()

    global key_story
    key_story = key
    global running
    running = True
    story_number = 0
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos
                story_number = func(x, y, story_number)
        show(screen, story_number)
        pygame.display.flip()
        clock.tick(60)
    return


if __name__ == '__main__':
    main(1)
