import cfg
from cfg import *
import demo_1_story
import demo_1_flight
import demo_1_flight1

# todo:完整流程分为几个小部分实现，分为选择、战斗、剧情三个板块
# todo:选择板块
#  有节点参数和模式参数，
#  利用节点参数来控制故事的节点
#  利用模式参数来进入战斗和剧情
#  方式：获取当前key，自动检索当前状态，并按顺序检索，自动播放当前剧情，进入选择，或者直接进入战斗
#       mode = 0 为该节点未开始
#       mode = 1 为该节点播放完剧情，正在进行选择
#       mode = 2 为该节点播放完剧情，正在进行战斗



# 界面跳转逻辑控制
str_back = Write("返回", color=color_white, font=font_path2, size=30)
rect_back = WriteRect(write=str_back, color=(0, 200, 0))
str_back1 = Write("单击鼠标以继续……", color=color_white, font=font_path2, size=30)
rect_back1 = WriteRect(write=str_back1, color=(0, 200, 0))
running = True

# 元素加载
background1 = Img(path=cfg.image_kg5)
background2 = Img(path=cfg.image_kg10)
str_ch1 = Write("溜过去", color="red", font=cfg.font_path2, size=30)
str_ch2 = Write("冲过去", color="red", font=cfg.font_path2, size=30)
rect_ch1 = WriteRect(write=str_ch1, color=color_white)
rect_ch2 = WriteRect(write=str_ch2, color=color_white)

# 游戏节点控制
game_key = 0
game_mode = 0
func_len = 0
func_add = 3
func_max = 200
flight_vector = 0


def show(screen):
    bg1 = [0, 1, 2, 3, 4, 7]
    bg2 = [5, 6, 8]
    screen.fill(color_black)
    if game_key in bg1:
        background1.show((400, 280), screen, mode=4)
    if game_key in bg2:
        background2.show((400, 280), screen, mode=4)
    if game_key == 0 and game_mode == 1:
        rect_ch1.show((200, 400), screen)
        rect_ch2.show((500, 400), screen)
    else:
        rect_back1.show((200, 500), screen)
    rect_back.show((50, 50), screen)



def func(x, y):
    # 获取当前状态信息
    global running
    global game_key
    global game_mode
    global flight_vector
    pos = (x, y)
    if rect_back.is_event(pos):
        running = False

    print(f"choose:{game_key },{game_mode}")
    # 加载状态转换逻辑
    mode0_key = [0, 1, 2, 3, 4, 5, 6, 7, 8]
    mode1_key = [0, 1, 2, 3]
    mode2_key = [2, 3, 5]
    # 进行状态更迭
    # 播放剧情
    if game_mode == 0:
        # 当前节点有剧情未播放
        if game_key in mode0_key:
            demo_1_story.main(game_key + 1)
        # 状态更迭
        game_mode = 1
        return
    # 进行选择
    if game_mode == 1:
        if game_key in [6, 8, 9]:
            running = False
        # 当前节点有选择未进行
        if game_key in mode1_key:
            if game_key == 0:
                global func_len
                if rect_ch1.is_event(pos):
                    game_mode = 0
                    game_key = 1
                if rect_ch2.is_event(pos):
                    game_mode = 0
                    game_key = 2
                if func_len > func_max:
                    game_mode = 0
                    game_key = 3
                    func_len = 0
                return
            if game_key == 1:
                game_mode = 0
                game_key = 5
            if game_key == 2:
                flight_vector = demo_1_flight.main()
                if not flight_vector:
                    game_key = 7
                game_mode = 0
                game_key = 4
            if game_key == 3:
                flight_vector = demo_1_flight.main()
                if not flight_vector:
                    game_key = 7
                game_mode = 0
                game_key = 4
            return

        # 状态更迭
        game_mode = 2
        return
    # 进行战斗
    if game_mode == 2:
        # 当前节点有战斗未进行
        if game_key in mode2_key:
            print("战斗")
            if game_key == 2 or game_key == 3:
                flight_vector = demo_1_flight.main()
                if not flight_vector:
                    game_key = 7
            if game_key == 5:
                if flight_vector:
                    keys = demo_1_flight1.main(1.5)
                    if not keys:
                        game_key = 8
                else:
                    keys = demo_1_flight1.main(1)
                    if not keys:
                        running = False

            # return
        # 状态更迭
        game_mode = 0
        game_key += 1
        return



def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("贺新春")
    clock = pygame.time.Clock()
    x, y = 0, 0
    global game_mode
    global game_key

    game_mode = 0
    game_key = 0


    global running
    global func_len
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos
                func(x, y)
        show(screen)
        if game_key == 0 and game_mode == 1:
            func_len += func_add
            pygame.draw.rect(screen, cfg.color_white, [300, 450, func_len, 30], 0)
            pygame.draw.rect(screen, cfg.color_black, [300, 450, func_max, 30], 2)
            if func_len > func_max:
                func(x, y)


        pygame.display.flip()
        clock.tick(60)


if __name__ == '__main__':
    main()
