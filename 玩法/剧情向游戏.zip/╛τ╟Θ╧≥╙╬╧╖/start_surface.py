import cfg
from cfg import *
import mean_surface
import story_surface1
import demo_1_choose

# 相关背景素材设置
background = Img(path=cfg.image_kg9)
str_start = Write("游戏开始", color="red", font=cfg.font_path2, size=30)
str_title = Write("蓝桥榜", color="red", font=cfg.font_path2, size=50)
str_mean = Write("游戏说明", color="red", font=cfg.font_path2, size=30)
rect_start = WriteRect(write=str_start, color=color_white)
rect_title = WriteRect(write=str_title, color=None)
rect_mean = WriteRect(write=str_mean, color=color_white)


def show(screen):
    # 相关素材绘制
    screen.fill(color_black)
    background.show((400, 280), screen, mode=4)
    rect_start.show((340, 300), screen)
    rect_title.show((325, 100), screen)
    rect_mean.show((340, 350), screen)


def func(x, y):
    # 相关事件判定
    pos = (x, y)
    if rect_start.is_event(pos):
        # story_surface1.main()
        demo_1_choose.main()
    if rect_mean.is_event(pos):
        mean_surface.main()


def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("贺新春")

    clock = pygame.time.Clock()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE or event.key == pygame.K_SPACE:
                    pygame.quit()
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos
                func(x, y)
        show(screen)
        pygame.display.flip()
        clock.tick(60)


if __name__ == '__main__':
    main()
